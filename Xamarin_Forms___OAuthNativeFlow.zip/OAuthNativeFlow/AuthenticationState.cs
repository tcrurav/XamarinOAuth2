﻿using Xamarin.Auth;

namespace OAuthNativeFlow
{
    public class AuthenticationState
    {
        public static OAuth2Authenticator Authenticator;
    }
}
